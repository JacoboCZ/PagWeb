<?php
include("bd/conexion.php");

$id = $_REQUEST['id'];
$nombre = $_POST['nombre'];
$precio = $_POST['precio'];
$imagen = "http://localhost/21310362/imgCatalogo/".$_FILES['imagen']['name'];
$query = "UPDATE productos SET nombre= '$nombre',precio= '$precio', imagen= '$imagen' WHERE id = '$id'";
file_put_contents("./imgCatalogo/".$_FILES['imagen']['name'],file_get_contents($_FILES['imagen']['tmp_name']));
$rest = $con->query($query);
if($rest){
    header("location: ../21310362/vistaAdmin.html");
}
else{
    echo"No se ha modificado";
}