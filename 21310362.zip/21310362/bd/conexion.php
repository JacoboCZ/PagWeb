<?php
$SERVER = "localhost";
$database = "gamerly";
$username = "root";
$password = "Lujacaza1";
$con = mysqli_connect($SERVER,$username,$password,$database) or die("".mysqli_error($con));


