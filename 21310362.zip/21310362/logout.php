<?php
include 'bd/conexion.php';
$json = json_decode(file_get_contents('php://input'));
if($json->session_id!=""){
    if(session_start(array($json->session_id))){
        http_response_code(200);
        if(isset($_SESSION["gamerly_user"])){
            unset($_SESSION["gamerly_user"]);
            session_abort(array($json->session_id));
            session_destroy(array($json->session_id));
            exit;
        }
        exit;
    }
    http_response_code(401);
    exit;
}
http_response_code(401);
?>
