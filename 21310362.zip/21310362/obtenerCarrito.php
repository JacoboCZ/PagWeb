<?php
include 'bd/conexion.php';
$json = json_decode(file_get_contents('php://input'));
//Se inicia sesion 
session_start(array($json->session_id));
$sesion=json_decode($_SESSION["gamerly_user"]);
//Se obtiene el carrito del usuario
$req = mysqli_query($con,"SELECT id FROM carrito WHERE fk_usuario=$sesion->id_usuario");
$carrito = mysqli_fetch_column($req);
//Se obtienen los articulos del carrito
$req = mysqli_query($con,"SELECT * FROM carrito_producto WHERE fk_carrito=$carrito");
$contenido = [];
if($req){
    while($element = mysqli_fetch_assoc($req)){
        $req2 = mysqli_query($con,"SELECT * FROM productos WHERE id='".$element["fk_producto"]."'");
        $element["producto"]=mysqli_fetch_assoc($req2);
        array_push($contenido,$element);
    }
}
echo json_encode(array(
    "carrito"=>$carrito,
    "productos"=>$contenido
));
?>
