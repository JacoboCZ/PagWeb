<?php
include("bd/conexion.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertar productos</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div class="header">
        <div class="navbars">
            <a href="Principal.html"> Home </a>
            <a href="Productos.php"> Productos</a>>
            <a href="logout.html">Logout</a>
            <a id="admin" href="vistaAdmin.html">Admin</a>
            <a href="ProductoAdministrador.php">Reg producto</a>
            <a href="ProdAdmin.php">Mod producto</a>
            <a href="usuarioAdministrador.php">Reg usuarios</a>
            <a href="mostrarUsuarios.php">Mod usuarios</a>
        </div>
    </div>
    <div class="grid">
    <form class="formRegistro" action="apoyoPA.php" method="POST" enctype= "multipart/form-data">

        <label for="">Ingrese el nombre</label>
        <input type="text" REQUIRED name="nombre">

        <label for="">Ingrese el precio</label>
        <input type="text" REQUIRED name="precio">

        <label for="">Ingrese una imágen</label>
        <input type="file" REQUIRED name="imagen">
        
        <button type="submit">Registrar</button>
    </form>
    </div>
    
</body>
</html>