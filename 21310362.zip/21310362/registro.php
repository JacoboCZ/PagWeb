<?php
include 'bd/conexion.php';
$json = json_decode(file_get_contents('php://input'));
$sql=mysqli_query($con, "INSERT INTO `usuarios`(`id`, `nombre`, `apellidos`, `correo`, `pass`, `codigopostal`, `edad`, auth) VALUES (0,'$json->nombre','$json->apellidos','$json->correo','$json->pass','$json->codigopostal','$json->fechanacimiento', 1)");
if(!mysqli_insert_id($con)){
    var_dump(mysqli_error($con));
    http_response_code(400);
    exit;
}
http_response_code(200);
echo json_encode(array("status"=>"true"));
exit;
?>