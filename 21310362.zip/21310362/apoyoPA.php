<?php
include 'bd/conexion.php';

$nombre = $_POST['nombre'];
$precio = $_POST['precio'];
$imagen = "http://localhost/21310362/imgCatalogo/".$_FILES['imagen']['name'];

$query= "INSERT INTO productos(nombre, precio, imagen) VALUES('$nombre','$precio','$imagen')";
$result= $con->query($query);

file_put_contents("./imgCatalogo/".$_FILES['imagen']['name'],file_get_contents($_FILES['imagen']['tmp_name']));

if($result){
    header("location: ../21310362/vistaAdmin.html");
}
else echo "Producto no agregado";
?>