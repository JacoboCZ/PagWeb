<?php
include("bd/conexion.php");
$sql = mysqli_query($con, 'SELECT * FROM usuarios');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MostrarProdAdmin</title>

    <link rel="stylesheet" href="estiloMostrarU.css">
</head>
<body>
    <div class="header">
        <div class="navbars">
            <a href="Principal.html"> Home </a>
            <a href="Productos.php"> Productos</a>>
            <a href="logout.html">Logout</a>
            <a id="admin" href="vistaAdmin.html">Admin</a>
            <a href="ProductoAdministrador.php">Reg producto</a>
            <a href="ProdAdmin.php">Mod producto</a>
            <a href="usuarioAdministrador.php">Reg usuarios</a>
            <a href="mostrarUsuarios.php">Mod usuarios</a>
        </div>
    </div>
    
    <center>
    <?php
    error_reporting(0);
    $buscar = $_REQUEST['buscar'];
    ?>
    <div style="margin:auto; align-items:center; text-align:center; margin-top:5%">
        <form action="buscadorUsr.php" method="get">
            <input style="width: 20%;" type="text" name="buscar" placeholder="Buscar" value="<?php echo $buscar;?>">
            <input type="submit" value="Buscar">
        </form>
    </div>
        <table class="tabla">
            <thead>
                <tr>
                    <th>id</th>
                    <th>nombre</th>
                    <th>apellidos</th>
                    <th>correo</th>
                    <th>contraseña</th>
                    <th>código postal</th>
                    <th>edad</th>
                    <th>rango</th>
                    <th colspan="2">Operaciónes</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    include("bd/conexion.php");
                    $query = "SELECT * FROM usuarios";
                    $rest = $con->query($query);
                    while($row = $rest->fetch_assoc()){
                ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['apellidos']; ?></td>
                    <td><?php echo $row['correo']; ?></td>
                    <td><?php echo $row['pass']; ?></td>
                    <td><?php echo $row['codigopostal']; ?></td>
                    <td><?php echo $row['edad']; ?></td>
                    <td><?php echo $row['auth']; ?></td>
                    <th><a href="modificarUsr.php?id=<?php echo $row['id']; ?>">Modificar</a></th><br>
                    <th><a href="eliminarUsr.php?id=<?php echo $row['id']; ?>">Eliminar</a></th>
                </tr>
                <?php
                    }
                    ?>
            </tbody>
        </table>
    </center>
</body>
</html>