<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="estilo.css">
    <link rel="stylesheet" href="estiloProductos.css">
</head>
<body>
    <div class="header">
        <div class="logo">
            <p>GamerLy</p>
        </div>
        <div class="navbar">
            <a id="login" href="login.html">Login</a>
            <a id="registro" href="registro.html">Registro</a>
            <a id="logout" href="logout.html">Logout</a>
            <a id="admin" href="vistaAdmin.html">Admin</a>
            <a  href="Ubicacion.html">Ubicacion</a>
            <a  href="Principal.html">Principal</a>
            <a  href="Productos.html">Catalogo</a>
        </div>
    </div>
    <div id="carrito">
        <p id="vacio">No haz añadido articulos a tu carrito</p>
    </div>
    <center> <p class="p" id="total"></p></center>
    <center><button class="shop2 shadow" onclick="comprar()"> Comprar </button></center>
    <button onclick="comprar"></button>
    <footer id="Pie">
        <p>Contáctanos <br>
        3331486511 <br>
        gamerly@contact.com</p>
    </footer> 
    <script>
        window.onload=async ()=>{
            await fetch("revisar_sesion.php",{
                method:"POST",
                headers:{
                    "Content-Type":"application/json"
                },
                body:JSON.stringify({
                    "session_id":localStorage.getItem("session_id"),
                })
            }).then(async (response)=>{carrito
                if(!response.ok){
                    document.getElementById("admin").setAttribute("class","hidden");
                    document.getElementById("logout").setAttribute("class","hidden");
                    alert("inicia sesion para acceder a esta funcion")
                    window.location.href="Principal.html";
                    return;
                }
                res= await response.json();
                document.getElementById("login").setAttribute("class","hidden");
                document.getElementById("registro").setAttribute("class","hidden");
                if(res.type!="2"){
                    document.getElementById("admin").setAttribute("class","hidden");
                }
                obtenerCarrito();
                return;
            })
        }
        async function obtenerCarrito (){
            let catalogo = await fetch("obtenerCarrito.php",{
                method:"POST",
                headers:{
                    "Content-Type":"application/json"
                },
                body:JSON.stringify({
                    "session_id":localStorage.getItem("session_id"),
                })
            }).then(async (response)=>{
                res= await response.json();
                console.log(res)
                return res;
            })
            localStorage.setItem("carrito",JSON.stringify(res))
            console.log(res);
            if(!res.productos==[]){
                document.getElementById("vacio").setAttribute("class","hidden")
                let contenedor = document.getElementById("carrito");
                let total=0;
                let inner=`<table><tr>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                </tr>`
                for(let i=0;i<res.productos.length;i++){
                    total+=res.productos[i].cantidad*res.productos[i].producto.precio;
                    inner= inner+`<tr>
                    <td>
                    <p class="p">`+res.productos[i].producto.nombre+`</p>
                    </td>
                    <td>
                    <p class="p">`+res.productos[i].producto.precio+`</p>
                    </td>
                    <td>
                    <p class="p">`+res.productos[i].cantidad+`</p>
                    </td>
                    <td>
                    <p class="p">`+res.productos[i].cantidad*res.productos[i].producto.precio+`</p>
                    </td>
                    </tr>`;
                }
                inner=inner+`<table>`
                contenedor.innerHTML=inner
                console.log(total)
                document.getElementById("total").innerHTML=total
                return
            }
            return
        }
        async function comprar(){
            let data={
                "id":localStorage.getItem("session_id"),
                "carrito":localStorage.getItem("carrito"),
                "total":document.getElementById("total").innerText
            }
            let catalogo = await fetch("realizar_compra.php",{
                method:"POST",
                headers:{
                    "Content-Type":"application/json"
                },
                body:JSON.stringify(data)
            }).then(async (response)=>{
                res= await response.json();
                console.log(res)
                return res;
            })
            alert("compra realizada");
            window.location.href="productos.php"
        }
    </script>
</body>
</html>

