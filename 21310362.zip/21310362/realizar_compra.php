<?php
include 'bd/conexion.php';
require "Mail.php";
require './fpdf/fpdf.php';

$json = json_decode(file_get_contents('php://input'));

session_start(array($json->id));
$sesion=json_decode($_SESSION["gamerly_user"]);

$query = mysqli_query($con, "SELECT correo FROM usuarios where id=$sesion->id_usuario");
$correo= mysqli_fetch_column($query);

$query = mysqli_query($con, "SELECT id FROM carrito where fk_usuario=$sesion->id_usuario");
$carrito_id= mysqli_fetch_column($query);

$query = mysqli_query($con, "INSERT INTO pedido VALUES(NULL,$sesion->id_usuario,$json->total,CURRENT_TIMESTAMP())");
$pedido_id= mysqli_insert_id($con);

$prod= json_decode($json->carrito);
$prod=$prod->productos;
for($i=0;$i<sizeof($prod);$i++){
    $query = mysqli_query($con, "INSERT INTO pedido_articulos VALUES(NULL,'".$prod[$i]->cantidad."','".$prod[$i]->fk_producto."',$pedido_id)");
}
$query = mysqli_query($con, "DELETE FROM carrito_producto where fk_carrito=$carrito_id");
$pdf = new FPDF();

$pdf->AddPage();

$pdf->SetTitle('Pedido');

$pdf->SetFont('helvetica', '', 10);
foreach ($prod as $element) {
    $precio = $element->cantidad*$element->producto->precio;
    $pdf->Cell(40,10, 'Nombre:'.$element->producto->nombre, 0, 1);
    $pdf->Cell(40,10, 'Precio : ' . $element->producto->precio, 0, 1);
    $pdf->Cell(40,10, 'Cantidad: ' . $element->cantidad, 0, 1);
    $pdf->Cell(40,10, 'SubTotal: ' . $precio , 0, 1);
}
$pdf->Cell(40,10, 'Total: ' . $json->total , 0, 1);

$pdf->Output('pdf/orden'.$sesion->id_usuario.'.pdf', 'F');
sendMail($sesion->id_usuario,$correo);
echo json_encode(array("estado"=>true));
exit;


